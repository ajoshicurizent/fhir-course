# Nationality (ISO 3166-1 Alpha-3 Subset) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Nationality (ISO 3166-1 Alpha-3 Subset)**

## ValueSet: Nationality (ISO 3166-1 Alpha-3 Subset) 

| | |
| :--- | :--- |
| *Official URL*:http://courses.ajoshi.org/fhir/ValueSet/patient-nationality-valueset | *Version*:0.1.0 |
| Active as of 2026-03-25 | *Computable Name*:PatientNationalityValueSet |
| **Copyright/Legal**: Used by permission of FHIR course Author. | |

 
ValueSet for the Countries represented using ISO 3166-1 alpha-3 codes. 

 **References** 

* [FHIR Course Extension Patient Nationality](StructureDefinition-patient-nationality-extension.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "patient-nationality-valueset",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "url" : "http://courses.ajoshi.org/fhir/ValueSet/patient-nationality-valueset",
  "version" : "0.1.0",
  "name" : "PatientNationalityValueSet",
  "title" : "Nationality (ISO 3166-1 Alpha-3 Subset)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-25T09:53:08+03:00",
  "publisher" : "Aditya Joshi (FHIR Trainer)",
  "contact" : [
    {
      "name" : "Aditya Joshi (FHIR Trainer)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.hl7.org/Special/committees/cgp"
        }
      ]
    }
  ],
  "description" : "ValueSet for the Countries represented using ISO 3166-1 alpha-3 codes.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
          "code" : "001",
          "display" : "World"
        }
      ]
    }
  ],
  "copyright" : "Used by permission of FHIR course Author.",
  "compose" : {
    "include" : [
      {
        "system" : "urn:iso:std:iso:3166"
      }
    ]
  }
}

```
