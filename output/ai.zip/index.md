# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://courses.ajoshi.org/fhir/ImplementationGuide/hl7.fhir.uv.fhir-course | *Version*:0.1.0 |
| Active as of 2026-03-10 | *Computable Name*:FHIRCourse |

*There are no Global profiles defined*
-->

### Introduction

 FHIR Course profiles and implementation guide for course assignments. 

### Technical Overview

 FHIR course IG is a set of rules and best practices that help healthcare providers share patient information safely and efficiently across the Kingdom of Saudi Arabia. It uses the FHIR standard to align how data —such as patient records, medications, and lab results — is formatted and exchanged. These rules follow national requirements, especially the Saudi-Health-Data-Dictionary-v2 data sets, ensuring hospitals and clinics share the most critical health data. 

 The main sections of this IG are: 

*  [Background](background.md) - provides business context for the implementation guide and information that implementers should be familiar with before reading the remainder of the IG. There could be multiple pages for this. 
*  [FHIR Artifacts](artifacts.md) - FHIR profiles, ValueSet, CodeSystem and extensions. 
*  [Downloads](downloads.md) - Allows downloading a copy of this implementation guide and other useful information 

